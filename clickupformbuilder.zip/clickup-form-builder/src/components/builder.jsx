'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Icon } from './icons';
import { cn, Btn, IconBtn, Input, Textarea, Select, Label, Switch, Badge } from './ui';
import PublicForm from './PublicForm';
import { saveForm, setPublish } from '@/lib/actions';
import {
  FIELD_TYPES, TASK_PROPERTIES, PRIORITIES, STATUSES, STATUS_LABEL,
  makeField, makeTP, computeKeys, iconFor, labelFor, slug, uid,
} from '@/lib/fieldTypes';

/* ---------- Canvas ---------- */
function Canvas({ fields, selectedId, onSelect, onReorder, onDup, onDel }) {
  const drag = useRef(null);
  const drop = (id) => {
    const from = fields.findIndex((f) => f.id === drag.current);
    const to = fields.findIndex((f) => f.id === id);
    if (from < 0 || to < 0 || from === to) return;
    const n = [...fields]; const [m] = n.splice(from, 1); n.splice(to, 0, m); onReorder(n); drag.current = null;
  };
  if (!fields.length) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-[#2c2c37] px-6 py-16 text-center">
        <Icon n="plus" size={30} className="text-zinc-700" />
        <p className="mt-3 text-sm font-semibold text-zinc-300">Your form is empty</p>
        <p className="mt-1 max-w-xs text-xs text-zinc-500">Use “Add question” below to add fields, then map inputs to task properties.</p>
      </div>
    );
  }
  return (
    <div className="space-y-2.5">
      {fields.map((fl) => {
        const sel = fl.id === selectedId; const t = fl.task_property;
        return (
          <div key={fl.id} draggable onDragStart={() => (drag.current = fl.id)} onDragOver={(e) => e.preventDefault()} onDrop={() => drop(fl.id)} onClick={() => onSelect(fl.id)}
            className={cn('group flex cursor-pointer items-start gap-3 rounded-xl border bg-[#14141a] p-3 transition', sel ? 'border-cu-purple ring-1 ring-cu-purple/40' : 'border-[#26262f] hover:border-[#3a3a46]')}>
            <span className="mt-0.5 cursor-grab text-zinc-600"><Icon n="grip" size={16} /></span>
            <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-[#22222b] text-zinc-300"><Icon n={iconFor(fl.field_type)} size={15} /></span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2"><span className="truncate text-sm font-semibold text-zinc-100">{fl.label || 'Untitled field'}</span>{fl.required && <span className="text-[#E5484D]">*</span>}</div>
              <div className="mt-1 flex flex-wrap items-center gap-1.5">
                <Badge>{labelFor(fl.field_type)}</Badge>
                {t && <Badge className="bg-[#10B981]/15 text-[#34d399]"><Icon n="link" size={11} /><span className="mono">{t.startsWith('custom:') ? t.slice(7) : 'task.' + t}</span></Badge>}
              </div>
            </div>
            <div className="flex shrink-0 items-center opacity-0 transition group-hover:opacity-100">
              <IconBtn onClick={(e) => { e.stopPropagation(); onDup(fl.id); }}><Icon n="copy" size={14} /></IconBtn>
              <IconBtn onClick={(e) => { e.stopPropagation(); onDel(fl.id); }}><Icon n="trash" size={14} /></IconBtn>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ---------- Add-question dropdown (ClickUp style) ---------- */
function AddQuestionMenu({ onAdd }) {
  const [open, setOpen] = useState(false);
  const [sub, setSub] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) { setOpen(false); setSub(false); } };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [open]);
  const pick = (fl) => { onAdd(fl); setOpen(false); setSub(false); };
  const Item = ({ icon, label, onClick, arrow }) => (
    <button onClick={onClick} className="flex w-full items-center gap-2.5 rounded-md px-2.5 py-2 text-left text-sm text-zinc-200 hover:bg-[#1c1c22]">
      <span className="text-zinc-400"><Icon n={icon} size={16} /></span>{label}{arrow && <Icon n="fwd" size={13} className="ml-auto text-zinc-500" />}
    </button>
  );
  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen((o) => !o)} className="flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-[#2c2c37] py-3 text-sm font-semibold text-zinc-400 transition hover:border-cu-purple/60 hover:text-zinc-200">
        <Icon n="plus" size={16} /> Add question
      </button>
      {open && (
        <div className="absolute left-0 top-full z-40 mt-2 w-[262px] rounded-xl border border-[#26262f] bg-[#0d0d12] p-1.5 shadow-2xl">
          <div className="relative" onMouseEnter={() => setSub(true)} onMouseLeave={() => setSub(false)}>
            <Item icon="braces" label="Task property" arrow onClick={() => setSub((s) => !s)} />
            {sub && (
              <div className="absolute left-full top-0 z-50 ml-1 w-[210px] rounded-xl border border-[#26262f] bg-[#0d0d12] p-1.5 shadow-2xl">
                {TASK_PROPERTIES.map((t) => <Item key={t.property} icon={t.icon} label={t.label} onClick={() => pick(makeTP(t.property))} />)}
              </div>
            )}
          </div>
          <div className="my-1 h-px bg-[#1e1e26]" />
          {FIELD_TYPES.map((ft) => <Item key={ft.type} icon={ft.icon} label={ft.label} onClick={() => pick(makeField(ft.type))} />)}
        </div>
      )}
    </div>
  );
}

/* ---------- Field editor ---------- */
function FieldEditor({ field, onChange, onClose }) {
  if (!field) return <div className="flex h-full items-center justify-center p-6 text-center text-sm text-zinc-600">Select a field to edit its properties.</div>;
  const set = (patch) => onChange({ ...field, ...patch });
  const opts = field.field_type === 'dropdown' || field.field_type === 'multi_select';
  const isCustom = (field.task_property || '').startsWith('custom:');
  const isInfo = field.field_type === 'info_block';
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-[#26262f] px-4 py-3"><h3 className="text-sm font-bold text-zinc-100">Field settings</h3><IconBtn onClick={onClose}><Icon n="x" size={16} /></IconBtn></div>
      <div className="flex-1 space-y-4 overflow-y-auto p-4">
        <div><Label>Label</Label><Input value={field.label} onChange={(e) => set({ label: e.target.value })} /></div>
        {!['signature', 'checkbox', 'rating', 'info_block'].includes(field.field_type) && <div><Label>Placeholder</Label><Input value={field.placeholder || ''} onChange={(e) => set({ placeholder: e.target.value })} /></div>}
        <div><Label>{isInfo ? 'Body text' : 'Help text'}</Label><Input value={field.help_text || ''} onChange={(e) => set({ help_text: e.target.value })} placeholder="Optional" /></div>
        {opts && (
          <div><Label>Options</Label>
            <div className="space-y-2">
              {field.options.map((o, i) => (
                <div key={i} className="flex items-center gap-2">
                  <Input value={o.label} onChange={(e) => set({ options: field.options.map((x, j) => (j === i ? { label: e.target.value, value: slug(e.target.value) } : x)) })} />
                  <IconBtn onClick={() => set({ options: field.options.filter((_, j) => j !== i) })}><Icon n="trash" size={14} /></IconBtn>
                </div>
              ))}
              <Btn variant="ghost" size="sm" onClick={() => set({ options: [...field.options, { label: 'Option ' + (field.options.length + 1), value: 'option_' + (field.options.length + 1) }] })}><Icon n="plus" size={14} /> Add option</Btn>
            </div>
          </div>
        )}
        {field.field_type === 'rating' && <div><Label>Max stars</Label><Select value={field.config?.scale || 5} onChange={(e) => set({ config: { ...field.config, scale: +e.target.value } })}>{[3, 5, 7, 10].map((n) => <option key={n} value={n}>{n}</option>)}</Select></div>}
        {field.field_type === 'file_upload' && <div><Label>Accepted types</Label><Input value={field.config?.accept || ''} onChange={(e) => set({ config: { ...field.config, accept: e.target.value } })} placeholder=".pdf,.png" /></div>}
        {!isInfo && (
          <>
            <div className="flex items-center justify-between rounded-lg border border-[#26262f] bg-[#14141a] px-3 py-2.5"><span className="text-sm text-zinc-200">Required</span><Switch checked={field.required} onChange={(v) => set({ required: v })} /></div>
            <div className="rounded-lg border border-[#10B981]/25 bg-[#10B981]/5 p-3">
              <Label className="text-[#34d399]">Map to task property</Label>
              <Select value={isCustom ? 'custom' : (field.task_property || '')} onChange={(e) => { const v = e.target.value; set({ task_property: v === '' ? null : v === 'custom' ? 'custom:' + (field.label || 'Custom field') : v }); }}>
                <option value="">None (plain answer)</option>{TASK_PROPERTIES.map((t) => <option key={t.property} value={t.property}>{t.label}</option>)}
              </Select>
              {isCustom && <div className="mt-2"><Label>Custom field name</Label><Input value={field.task_property.slice(7)} onChange={(e) => set({ task_property: 'custom:' + e.target.value })} placeholder="e.g. Budget" /></div>}
              <p className="mt-2 text-xs text-[#34d399]/70">Submitted values flow into the generated task automatically.</p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/* ---------- Settings ---------- */
const PRESETS = ['#7B68EE', '#EC4899', '#10B981', '#F5A524', '#3B82F6', '#E5484D', '#8B5CF6', '#14B8A6'];
function SettingsPanel({ form, set }) {
  const tt = form.task_template || {};
  const Section = ({ icon, title, desc, children }) => (
    <section className="rounded-xl border border-[#26262f] bg-[#14141a] p-5">
      <div className="mb-4 flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-lg bg-cu-purple/15 text-cu-purpleTint"><Icon n={icon} size={18} /></span><div><h3 className="text-sm font-bold text-zinc-100">{title}</h3><p className="text-xs text-zinc-500">{desc}</p></div></div>
      <div className="space-y-4">{children}</div>
    </section>
  );
  const Row = ({ label, hint, children }) => <div className="flex items-center justify-between gap-4"><div><p className="text-sm text-zinc-200">{label}</p>{hint && <p className="text-xs text-zinc-500">{hint}</p>}</div>{children}</div>;
  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <Section icon="eye" title="Form styling" desc="How the public form looks.">
        <div><Label>Theme</Label><div className="inline-flex rounded-lg border border-[#26262f] bg-[#0f0f14] p-1">{[['light', 'sun', 'Light'], ['dark', 'moon', 'Dark']].map(([v, ic, lb]) => <button key={v} onClick={() => set({ theme: v })} className={cn('inline-flex items-center gap-2 rounded-md px-4 py-1.5 text-sm font-medium transition', form.theme === v ? 'bg-cu-purple text-white' : 'text-zinc-400 hover:text-zinc-100')}><Icon n={ic} size={15} />{lb}</button>)}</div></div>
        <div><Label>Primary color</Label><div className="flex flex-wrap items-center gap-3"><input type="color" value={form.primary_color} onChange={(e) => set({ primary_color: e.target.value })} className="h-9 w-12 cursor-pointer rounded-md border border-[#2c2c37] bg-transparent p-1" /><Input value={form.primary_color} onChange={(e) => set({ primary_color: e.target.value })} className="w-32 mono" /><div className="flex gap-1.5">{PRESETS.map((c) => <button key={c} onClick={() => set({ primary_color: c })} className={cn('h-6 w-6 rounded-full border-2', form.primary_color === c ? 'border-white' : 'border-transparent')} style={{ background: c }} />)}</div></div></div>
      </Section>
      <Section icon="send" title="Submission" desc="What happens on submit.">
        <div><Label>Submit button label</Label><Input value={form.submit_label} onChange={(e) => set({ submit_label: e.target.value })} /></div>
        <div><Label>Success message</Label><Textarea value={form.success_message || ''} onChange={(e) => set({ success_message: e.target.value })} /></div>
        <div><Label>Redirect URL (optional)</Label><Input value={form.redirect_url || ''} onChange={(e) => set({ redirect_url: e.target.value })} placeholder="https://example.com/thank-you" /></div>
        <Row label="Enable reCAPTCHA" hint="Protect against spam."><Switch checked={form.recaptcha_enabled} onChange={(v) => set({ recaptcha_enabled: v })} /></Row>
        <Row label="Show TAKSAM branding" hint="“Powered by” footer."><Switch checked={form.branding_enabled} onChange={(v) => set({ branding_enabled: v })} /></Row>
      </Section>
      <Section icon="spark" title="Task automation" desc="How generated tasks are created.">
        <div><Label>Auto-assign tasks to</Label><Input value={form.auto_assign_name || ''} onChange={(e) => set({ auto_assign_name: e.target.value })} placeholder="Team member name" /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Default status</Label><Select value={form.default_status} onChange={(e) => set({ default_status: e.target.value })}>{STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}</Select></div>
          <div><Label>Default priority</Label><Select value={form.default_priority || ''} onChange={(e) => set({ default_priority: e.target.value || null })}><option value="">None</option>{Object.keys(PRIORITIES).map((p) => <option key={p} value={p}>{PRIORITIES[p].label}</option>)}</Select></div>
        </div>
        <div><Label>Task template — default tags</Label><Input value={(tt.tags || []).join(', ')} onChange={(e) => set({ task_template: { ...tt, tags: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) } })} placeholder="intake, web (comma separated)" /></div>
      </Section>
    </div>
  );
}

/* ---------- Preview ---------- */
function PreviewPane({ form, fields }) {
  const dark = form.theme === 'dark';
  return (
    <div className="h-full overflow-auto rounded-xl border border-[#26262f]">
      <div className={dark ? 'min-h-full bg-[#0f0f14]' : 'min-h-full bg-zinc-100'}>
        <PublicForm form={{ ...form, public_id: form.public_id }} fields={computeKeys(fields)} preview />
      </div>
    </div>
  );
}

/* ---------- FormBuilder ---------- */
const FORM_COLUMNS = ['name', 'description', 'theme', 'primary_color', 'submit_label', 'success_message', 'redirect_url', 'recaptcha_enabled', 'branding_enabled', 'auto_assign_name', 'default_status', 'default_priority', 'task_template'];

export default function FormBuilder({ initialForm, initialFields, locationLabel }) {
  const router = useRouter();
  const [form, setForm] = useState(initialForm);
  const [fields, setFields] = useState(initialFields || []);
  const [tab, setTab] = useState('build');
  const [selectedId, setSelectedId] = useState(initialFields?.[0]?.id || null);
  const [saving, setSaving] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [copied, setCopied] = useState(false);
  const [toast, setToast] = useState('');

  const patchForm = (patch) => { setForm((f) => ({ ...f, ...patch })); setDirty(true); };
  const updateFields = (next) => { setFields(next); setDirty(true); };
  const selected = useMemo(() => fields.find((f) => f.id === selectedId) || null, [fields, selectedId]);
  const published = form.status === 'published';
  const publicUrl = typeof window !== 'undefined' ? `${window.location.origin}/f/${form.public_id}` : `/f/${form.public_id}`;
  const flash = (m) => { setToast(m); setTimeout(() => setToast(''), 2400); };

  const addField = (fl) => { updateFields([...fields, { ...fl, position: fields.length }]); setSelectedId(fl.id); };
  const changeField = (up) => updateFields(fields.map((f) => (f.id === up.id ? up : f)));
  const dupField = (id) => { const i = fields.findIndex((f) => f.id === id); if (i < 0) return; const c = { ...fields[i], id: uid(), label: fields[i].label + ' (copy)' }; const n = [...fields]; n.splice(i + 1, 0, c); updateFields(n); setSelectedId(c.id); };
  const delField = (id) => { updateFields(fields.filter((f) => f.id !== id)); if (selectedId === id) setSelectedId(null); };

  const save = async () => {
    setSaving(true);
    try { const patch = {}; FORM_COLUMNS.forEach((c) => { patch[c] = form[c]; }); await saveForm(form.id, patch, fields); setDirty(false); flash('Form saved'); return true; }
    catch (e) { flash(e.message || 'Save failed'); return false; }
    finally { setSaving(false); }
  };
  const togglePublish = async () => {
    setPublishing(true);
    try { if (dirty) { const ok = await save(); if (!ok) return; } const next = published ? 'draft' : 'published'; await setPublish(form.id, next); patchForm({ status: next }); setDirty(false); flash(next === 'published' ? 'Form published' : 'Form unpublished'); }
    catch (e) { flash(e.message || 'Failed'); }
    finally { setPublishing(false); }
  };
  const copyLink = async () => { try { await navigator.clipboard.writeText(publicUrl); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch { /* ignore */ } };

  const TABS = [['build', 'blocks', 'Build'], ['settings', 'settings', 'Settings'], ['preview', 'eye', 'Preview']];

  return (
    <div className="flex min-w-0 flex-1 flex-col bg-[#0d0d10]">
      <div className="flex flex-wrap items-center gap-3 border-b border-[#1e1e24] px-4 py-2.5">
        <IconBtn onClick={() => router.push('/forms')} title="Back to Forms"><Icon n="back" /></IconBtn>
        <div className="min-w-0">
          <input value={form.name} onChange={(e) => patchForm({ name: e.target.value })} className="w-48 truncate rounded bg-transparent px-1 text-sm font-bold text-zinc-100 outline-none hover:bg-[#1b1b23] focus:bg-[#1b1b23]" />
          <div className="flex items-center gap-1.5 px-1"><Icon n="pin" size={11} className="text-zinc-600" /><span className="text-[11px] text-zinc-500">{locationLabel}</span><Badge className={published ? 'bg-[#10B981]/15 text-[#34d399]' : 'bg-[#F5A524]/15 text-[#f5c17a]'}>{published ? 'Published' : 'Draft'}</Badge></div>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {published && (
            <>
              <IconBtn title="Board" onClick={() => router.push(`/board/${form.list_id || 'all'}?form=${form.id}`)}><Icon n="board" /></IconBtn>
              <IconBtn title={copied ? 'Copied' : 'Copy link'} onClick={copyLink}>{copied ? <Icon n="check" className="text-emerald-400" /> : <Icon n="copy" />}</IconBtn>
              <a href={publicUrl} target="_blank" rel="noreferrer"><IconBtn title="Open public form"><Icon n="external" /></IconBtn></a>
            </>
          )}
          <div className="inline-flex rounded-lg bg-[#141418] p-1 border border-[#26262f]">{TABS.map(([v, ic, lb]) => <button key={v} onClick={() => setTab(v)} className={cn('inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-semibold transition', tab === v ? 'bg-cu-purple text-white' : 'text-zinc-400 hover:text-zinc-100')}><Icon n={ic} size={15} />{lb}</button>)}</div>
          <Btn size="sm" variant="secondary" onClick={save} disabled={saving || !dirty}>{saving ? <Icon n="loader" size={15} className="animate-spin" /> : <Icon n="check" size={15} />} Save</Btn>
          <Btn size="sm" variant={published ? 'outline' : 'primary'} onClick={togglePublish} disabled={publishing}>{publishing ? <Icon n="loader" size={15} className="animate-spin" /> : <Icon n="send" size={15} />} {published ? 'Unpublish' : 'Publish'}</Btn>
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-hidden">
        {tab === 'build' && (
          <div className="grid h-full grid-cols-1 lg:grid-cols-[1fr_336px]">
            <div className="overflow-y-auto p-6"><div className="mx-auto max-w-2xl">
              <div className="mb-4"><h2 className="text-sm font-bold text-zinc-200">Canvas</h2><p className="text-xs text-zinc-500">{fields.length} field{fields.length === 1 ? '' : 's'}</p></div>
              <Canvas fields={fields} selectedId={selectedId} onSelect={setSelectedId} onReorder={updateFields} onDup={dupField} onDel={delField} />
              <div className="mt-3"><AddQuestionMenu onAdd={addField} /></div>
            </div></div>
            <aside className="hidden border-l border-[#1e1e24] bg-[#0d0d12] lg:block"><FieldEditor field={selected} onChange={changeField} onClose={() => setSelectedId(null)} /></aside>
          </div>
        )}
        {tab === 'settings' && <div className="h-full overflow-y-auto p-6"><SettingsPanel form={form} set={patchForm} /></div>}
        {tab === 'preview' && <div className="h-full p-6"><PreviewPane form={form} fields={fields} /></div>}
      </div>

      {toast && <div className="fixed bottom-4 left-1/2 z-50 -translate-x-1/2 rounded-lg border border-[#33333f] bg-[#141418] px-4 py-2 text-sm text-zinc-200 shadow-xl">{toast}</div>}
    </div>
  );
}
