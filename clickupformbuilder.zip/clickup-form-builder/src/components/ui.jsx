'use client';
import { Icon } from './icons';

export const cn = (...a) => a.filter(Boolean).join(' ');

export function Btn({ variant = 'primary', size = 'md', children, className, ...p }) {
  const V = {
    primary: 'bg-cu-purple hover:bg-cu-purpleHover text-white',
    secondary: 'bg-[#22222b] hover:bg-[#2c2c37] text-zinc-100 border border-[#33333f]',
    outline: 'bg-transparent hover:bg-[#1b1b23] text-zinc-200 border border-[#33333f]',
    ghost: 'bg-transparent hover:bg-[#1b1b23] text-zinc-300',
    danger: 'bg-[#E5484D] hover:bg-[#d43b40] text-white',
  }[variant];
  const S = { sm: 'h-8 px-3 text-xs gap-1.5', md: 'h-9 px-4 text-sm gap-2' }[size];
  return (
    <button className={cn('inline-flex items-center justify-center rounded-lg font-semibold transition-colors disabled:opacity-40 disabled:pointer-events-none', V, S, className)} {...p}>
      {children}
    </button>
  );
}

export function IconBtn({ children, className, ...p }) {
  return (
    <button className={cn('inline-flex h-8 w-8 items-center justify-center rounded-md text-zinc-400 hover:bg-[#22222b] hover:text-zinc-100 transition-colors', className)} {...p}>
      {children}
    </button>
  );
}

const INPUT = 'w-full rounded-lg border border-[#2c2c37] bg-[#0f0f14] px-3 py-2 text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-cu-purple transition';
export const Input = (p) => <input {...p} className={cn(INPUT, p.className)} />;
export const Textarea = (p) => <textarea {...p} className={cn(INPUT, 'min-h-[76px] resize-y', p.className)} />;
export const Select = ({ children, className, ...p }) => <select {...p} className={cn(INPUT, 'cursor-pointer', className)}>{children}</select>;
export const Label = ({ children, className }) => <label className={cn('mb-1.5 block text-xs font-semibold uppercase tracking-wide text-zinc-500', className)}>{children}</label>;

export function Switch({ checked, onChange }) {
  return (
    <button type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)}
      className={cn('relative h-5 w-9 shrink-0 rounded-full transition-colors', checked ? 'bg-cu-purple' : 'bg-[#33333f]')}>
      <span className={cn('absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all', checked ? 'left-[18px]' : 'left-0.5')} />
    </button>
  );
}

export function Badge({ children, className, color }) {
  return (
    <span className={cn('inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold', !color && 'bg-[#22222b] text-zinc-300', className)}
      style={color ? { background: color + '22', color } : undefined}>
      {children}
    </span>
  );
}

export const Spinner = ({ className }) => <Icon n="loader" className={cn('animate-spin', className)} />;
