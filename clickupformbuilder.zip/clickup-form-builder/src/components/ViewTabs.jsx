'use client';
import Link from 'next/link';
import { Icon } from './icons';
import { cn } from './ui';

// ClickUp-style view switcher: List | Board | <Form name>.
// Scoped to a form and its target list so all three views show the same data.
export default function ViewTabs({ formId = null, formName = 'Form', listId = null, active }) {
  const lid = listId || 'all';
  const q = formId ? `?form=${formId}` : '';
  const tabs = [
    { key: 'list', label: 'List', icon: 'list', href: `/list/${lid}${q}` },
    { key: 'board', label: 'Board', icon: 'board', href: `/board/${lid}${q}` },
  ];
  if (formId) tabs.push({ key: 'form', label: formName || 'Form', icon: 'align', href: `/forms/${formId}` });

  return (
    <div className="flex shrink-0 items-center gap-1 border-b border-[#1e1e24] bg-[#0f0f12] px-3">
      {tabs.map((t) => (
        <Link
          key={t.key}
          href={t.href}
          className={cn(
            'flex items-center gap-1.5 border-b-2 px-3 py-2.5 text-sm transition',
            active === t.key
              ? 'border-cu-purple font-semibold text-zinc-100'
              : 'border-transparent text-zinc-500 hover:text-zinc-200',
          )}
        >
          <Icon n={t.icon} size={15} />
          <span className="max-w-[160px] truncate">{t.label}</span>
        </Link>
      ))}
      <button title="Add view" className="ml-1 flex h-6 w-6 items-center justify-center rounded text-zinc-600 hover:bg-[#1c1c22] hover:text-zinc-300">
        <Icon n="plus" size={14} />
      </button>
    </div>
  );
}
