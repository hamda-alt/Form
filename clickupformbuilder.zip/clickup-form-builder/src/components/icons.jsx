import * as L from 'lucide-react';

// String keys (used across fieldTypes/templates) -> lucide component names.
const MAP = {
  type: 'Type', align: 'AlignLeft', mail: 'Mail', phone: 'Phone', hash: 'Hash',
  chevSquare: 'ChevronDown', checks: 'ListChecks', checkbox: 'CheckSquare', cal: 'Calendar',
  star: 'Star', clip: 'Paperclip', pen: 'PenLine', info: 'Info', plus: 'Plus', x: 'X',
  trash: 'Trash2', copy: 'Copy', grip: 'GripVertical', link: 'Link2', pin: 'MapPin',
  upload: 'Upload', sun: 'Sun', moon: 'Moon', external: 'ExternalLink', flag: 'Flag',
  user: 'User', clock: 'Clock', tag: 'Tag', spark: 'Sparkles', list: 'List', braces: 'Braces',
  layers: 'Layers', cart: 'ShoppingCart', home: 'Home', inbox: 'Inbox', goal: 'Target',
  grid: 'Grid3x3', bell: 'Bell', search: 'Search', back: 'ArrowLeft', fwd: 'ArrowRight',
  check: 'Check', checkCircle: 'CheckCircle2', chevDown: 'ChevronDown', chevUp: 'ChevronUp',
  settings: 'Settings2', board: 'LayoutGrid', eye: 'Eye', send: 'Send', blocks: 'Blocks',
  circle: 'Circle', video: 'Video', mic: 'Mic', loader: 'Loader2', refresh: 'RefreshCw',
  dots: 'MoreHorizontal',
};

// `n` is a string key; falls back to a circle if a name is ever missing.
export function Icon({ n, size = 18, className, strokeWidth = 2, style }) {
  const Cmp = L[MAP[n]] || L.Circle;
  return <Cmp size={size} className={className} strokeWidth={strokeWidth} style={style} />;
}
