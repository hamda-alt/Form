'use client';
import { useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Icon } from './icons';
import { cn, IconBtn, Badge } from './ui';
import { moveTask, updateTask, deleteTask, duplicateTask, createTask, updateListStatuses } from '@/lib/actions';
import { PRIORITIES, STATUS_LABEL, STATUS_DOT, uid, slug } from '@/lib/fieldTypes';

const GROUP_COLORS = ['#8b95a5', '#EC4899', '#14B8A6', '#F5A524', '#8B5CF6', '#E5484D', '#3B82F6'];
const labelFor = (k) => STATUS_LABEL[k] || k.replace(/_/g, ' ').toUpperCase();
const colorFor = (k, i) => STATUS_DOT[k] || GROUP_COLORS[i % GROUP_COLORS.length];

// Accept either legacy string keys or rich {key,label,color} objects so custom
// group names/colors survive a reload (they are persisted as objects).
const normalizeCols = (arr) =>
  (arr && arr.length ? arr : ['todo', 'in_progress', 'complete']).map((c, i) =>
    typeof c === 'string'
      ? { key: c, label: labelFor(c), color: colorFor(c, i) }
      : { key: c.key, label: c.label || labelFor(c.key), color: c.color || colorFor(c.key, i) });

function MenuItem({ icon, label, onClick, danger }) {
  return <button onClick={onClick} className={cn('flex w-full items-center gap-2.5 rounded-md px-2.5 py-2 text-left text-sm hover:bg-[#1c1c22]', danger ? 'text-[#ff6b6b]' : 'text-zinc-200')}><Icon n={icon} size={15} />{label}</button>;
}

// Chips shown on a task (priority / assignee / due / tags). Shared by both layouts.
function TaskMeta({ t }) {
  const pm = PRIORITIES[t.priority];
  return (
    <>
      {pm && <Badge color={pm.color}><Icon n="flag" size={11} />{pm.label}</Badge>}
      {t.assignee_name && <Badge><Icon n="user" size={11} />{t.assignee_name}</Badge>}
      {t.due_date && <Badge><Icon n="clock" size={11} />{String(t.due_date).slice(0, 10)}</Badge>}
      {(t.tags || []).map((tg, i) => <Badge key={i} className="bg-cu-purple/15 text-cu-purpleTint"><Icon n="tag" size={11} />{String(tg)}</Badge>)}
    </>
  );
}

export default function Board({ title, statuses, tasks: initial, listId = null, formId = null, layout = 'board' }) {
  const router = useRouter();
  const isList = layout === 'list';
  const [tasks, setTasks] = useState(initial || []);
  const [cols, setCols] = useState(() => normalizeCols(statuses));
  const drag = useRef(null);
  const [over, setOver] = useState(null);
  const [menu, setMenu] = useState(null);       // task menu
  const [colMenu, setColMenu] = useState(null); // group menu
  const [collapsed, setCollapsed] = useState({});
  const [adding, setAdding] = useState(null);
  const [addText, setAddText] = useState('');
  const [newGroup, setNewGroup] = useState(false);
  const [newText, setNewText] = useState('');

  const colByKey = (k) => cols.find((c) => c.key === k);
  const firstKey = cols[0] ? cols[0].key : 'todo';
  const grouped = {}; cols.forEach((c) => (grouped[c.key] = []));
  tasks.forEach((t) => (grouped[t.status] || grouped[firstKey]).push(t));

  const openMenu = (id, x, y) => setMenu({ id, x: Math.min(x, (typeof window !== 'undefined' ? window.innerWidth : 1200) - 234), y });
  const menuTask = menu && tasks.find((t) => t.id === menu.id);

  const move = async (id, status) => { const t = tasks.find((x) => x.id === id); if (!t || t.status === status) return; setTasks((ts) => ts.map((x) => (x.id === id ? { ...x, status } : x))); try { await moveTask(id, status); } catch { router.refresh(); } };
  const patch = async (id, p) => { setTasks((ts) => ts.map((x) => (x.id === id ? { ...x, ...p } : x))); try { await updateTask(id, p); } catch { router.refresh(); } };
  const del = async (id) => { setTasks((ts) => ts.filter((x) => x.id !== id)); try { await deleteTask(id); } catch { router.refresh(); } };
  const dup = async (id) => { const t = tasks.find((x) => x.id === id); if (!t) return; setTasks((ts) => [{ ...t, id: uid(), name: t.name + ' (copy)' }, ...ts]); try { await duplicateTask(id); } catch { router.refresh(); } };
  const renameTask = (t) => { const v = window.prompt('Rename task', t.name); if (v != null && v.trim()) patch(t.id, { name: v.trim() }); };

  const addTaskTo = async (key) => {
    const name = addText.trim(); setAddText(''); setAdding(null);
    if (!name) return;
    const tempId = uid();
    setTasks((ts) => [{ id: tempId, name, status: key, priority: null, assignee_name: null, due_date: null, tags: [], custom_fields: {} }, ...ts]);
    try { await createTask({ listId, formId, status: key, name }); } catch { router.refresh(); }
  };
  // Persist the full column objects (key + label + color) so custom names/colors
  // survive a reload — not just the keys.
  const persistCols = (next) => { updateListStatuses(listId, next).catch(() => {}); };
  const addGroup = async () => {
    const name = newText.trim(); setNewText(''); setNewGroup(false);
    if (!name) return;
    const key = slug(name) + '_' + Math.random().toString(36).slice(2, 5);
    const next = [...cols, { key, label: name.toUpperCase(), color: GROUP_COLORS[cols.length % GROUP_COLORS.length] }];
    setCols(next); persistCols(next);
  };
  const renameGroup = (c) => {
    const v = window.prompt('Rename group', c.label);
    if (v == null || !v.trim()) return;
    const next = cols.map((x) => (x.key === c.key ? { ...x, label: v.trim().toUpperCase() } : x));
    setCols(next); persistCols(next);
  };
  const deleteGroup = async (c) => {
    if ((grouped[c.key] || []).length) { window.alert('Move or delete this group’s tasks first.'); return; }
    const next = cols.filter((x) => x.key !== c.key); setCols(next); persistCols(next);
  };

  const dragProps = (id) => ({
    draggable: true,
    onDragStart: () => { drag.current = id; },
    onDragEnd: () => { drag.current = null; setOver(null); },
  });
  const dropProps = (s) => ({
    onDragOver: (e) => { e.preventDefault(); if (over !== s) setOver(s); },
    onDragLeave: () => setOver((o) => (o === s ? null : o)),
    onDrop: () => { if (drag.current) move(drag.current, s); drag.current = null; setOver(null); },
  });
  const addTaskInput = (s) => (
    <input autoFocus value={addText} onChange={(e) => setAddText(e.target.value)}
      onKeyDown={(e) => { if (e.key === 'Enter') addTaskTo(s); if (e.key === 'Escape') { setAdding(null); setAddText(''); } }}
      onBlur={() => addTaskTo(s)} placeholder="Task name, then Enter"
      className="w-full rounded-lg border border-cu-purple bg-[#0d0d12] px-3 py-2 text-sm text-zinc-100 outline-none" />
  );

  return (
    <div className="flex min-w-0 flex-1 flex-col bg-[#0d0d10]">
      <div className="flex items-center gap-3 border-b border-[#1e1e24] px-4 py-2.5">
        <IconBtn onClick={() => router.push('/forms')} title="Back to Forms"><Icon n="back" /></IconBtn>
        <div><h1 className="text-sm font-bold text-zinc-100">{title}</h1><p className="text-xs text-zinc-500">＋ Add Task / Add group, drag to move, group ⋯ to rename·collapse·delete, card ✓ / ⋯ for the rest</p></div>
        <IconBtn className="ml-auto" title="Refresh" onClick={() => router.refresh()}><Icon n="refresh" /></IconBtn>
      </div>

      {isList ? (
        /* ---------- LIST LAYOUT ---------- */
        <div className="min-h-0 flex-1 overflow-y-auto p-5">
          <div className="mx-auto max-w-4xl space-y-4">
            {cols.map((c) => {
              const s = c.key; const rows = grouped[s] || []; const open = !collapsed[s];
              return (
                <section key={s} {...dropProps(s)} className={cn('overflow-hidden rounded-xl border bg-[#14141a] transition-colors', over === s ? 'border-cu-purple' : 'border-[#26262f]')}>
                  <div className="flex items-center gap-2 px-3 py-2.5">
                    <button onClick={() => setCollapsed((m) => ({ ...m, [s]: !m[s] }))} title={open ? 'Collapse' : 'Expand'} className="text-zinc-500 hover:text-zinc-200"><Icon n={open ? 'chevDown' : 'fwd'} size={15} /></button>
                    <span className="inline-flex items-center gap-1.5 rounded px-2 py-0.5 text-[11px] font-bold tracking-wide" style={{ background: c.color + '22', color: c.color }}><span className="h-1.5 w-1.5 rounded-full" style={{ background: c.color }} />{c.label}</span>
                    <Badge>{rows.length}</Badge>
                    <button title="Group options" onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); setColMenu({ key: s, x: Math.min(r.right - 180, window.innerWidth - 190), y: r.bottom + 4 }); }} className="ml-auto flex h-6 w-6 items-center justify-center rounded text-zinc-500 hover:bg-[#22222b] hover:text-zinc-100"><Icon n="dots" size={14} /></button>
                  </div>
                  {open && (
                    <div className="border-t border-[#26262f]">
                      {rows.length === 0 && adding !== s && <p className="px-4 py-3 text-xs text-zinc-600">No tasks — add one below.</p>}
                      {rows.map((t) => (
                        <div key={t.id} {...dragProps(t.id)} onContextMenu={(e) => { e.preventDefault(); openMenu(t.id, e.clientX, e.clientY); }}
                          className="group flex cursor-grab items-center gap-2 border-t border-[#1e1e26] px-4 py-2 transition hover:bg-[#17171d] active:cursor-grabbing">
                          <span className="text-zinc-600"><Icon n="grip" size={14} /></span>
                          <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: (colByKey(t.status) || c).color }} />
                          <span className="min-w-0 flex-1 truncate text-sm text-zinc-100">{t.name}</span>
                          <div className="flex flex-wrap items-center justify-end gap-1.5"><TaskMeta t={t} /></div>
                          <div className="flex shrink-0 items-center gap-0.5 opacity-0 transition group-hover:opacity-100">
                            <button title="Mark complete" onClick={(e) => { e.stopPropagation(); move(t.id, 'complete'); }} className="flex h-6 w-6 items-center justify-center rounded text-zinc-400 hover:bg-[#22222b] hover:text-emerald-400"><Icon n="check" size={14} /></button>
                            <button title="More" onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); openMenu(t.id, r.right - 220, r.bottom + 4); }} className="flex h-6 w-6 items-center justify-center rounded text-zinc-400 hover:bg-[#22222b] hover:text-zinc-100"><Icon n="dots" size={14} /></button>
                          </div>
                        </div>
                      ))}
                      <div className="border-t border-[#1e1e26] px-4 py-2">
                        {adding === s ? addTaskInput(s)
                          : <button onClick={() => { setAdding(s); setAddText(''); }} className="flex items-center gap-1.5 text-left text-xs font-semibold text-zinc-500 transition hover:text-zinc-200"><Icon n="plus" size={13} /> Add Task</button>}
                      </div>
                    </div>
                  )}
                </section>
              );
            })}
            {newGroup
              ? <input autoFocus value={newText} onChange={(e) => setNewText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') addGroup(); if (e.key === 'Escape') { setNewGroup(false); setNewText(''); } }} onBlur={addGroup} placeholder="Group name, then Enter" className="w-full rounded-lg border border-cu-purple bg-[#14141a] px-3 py-2 text-sm text-zinc-100 outline-none" />
              : <button onClick={() => { setNewGroup(true); setNewText(''); }} className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-semibold text-zinc-500 transition hover:text-zinc-200"><Icon n="plus" size={15} /> Add group</button>}
          </div>
        </div>
      ) : (
        /* ---------- BOARD LAYOUT ---------- */
        <div className="min-h-0 flex-1 p-5">
          <div className="flex h-full gap-4 overflow-x-auto" style={{ minWidth: 'min-content' }}>
            {cols.map((c) => {
              const s = c.key;
              if (collapsed[s]) return <div key={s} onClick={() => setCollapsed((m) => ({ ...m, [s]: false }))} title="Expand group" className="flex w-10 shrink-0 cursor-pointer flex-col items-center gap-2 rounded-xl border border-[#26262f] bg-[#14141a] py-3"><Badge>{grouped[s].length}</Badge><span className="mt-1 text-[11px] font-bold tracking-wide" style={{ color: c.color, writingMode: 'vertical-rl' }}>{c.label}</span></div>;
              return (
                <div key={s} {...dropProps(s)}
                  className={cn('flex w-[300px] shrink-0 flex-col rounded-xl border bg-[#14141a] transition-colors', over === s ? 'border-cu-purple' : 'border-[#26262f]')}>
                  <div className="flex items-center justify-between border-b border-[#26262f] px-3 py-2.5">
                    <span className="inline-flex items-center gap-1.5 rounded px-2 py-0.5 text-[11px] font-bold tracking-wide" style={{ background: c.color + '22', color: c.color }}><span className="h-1.5 w-1.5 rounded-full" style={{ background: c.color }} />{c.label}</span>
                    <div className="flex items-center gap-1"><Badge>{grouped[s].length}</Badge><button title="Group options" onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); setColMenu({ key: s, x: Math.min(r.right - 180, window.innerWidth - 190), y: r.bottom + 4 }); }} className="flex h-6 w-6 items-center justify-center rounded text-zinc-500 hover:bg-[#22222b] hover:text-zinc-100"><Icon n="dots" size={14} /></button></div>
                  </div>
                  <div className="flex-1 space-y-2.5 overflow-y-auto p-2.5">
                    {grouped[s].length === 0 && adding !== s && <p className="rounded-lg border border-dashed border-[#26262f] px-1 py-5 text-center text-xs text-zinc-600">Drop tasks here</p>}
                    {grouped[s].map((t) => {
                      const cust = Object.entries(t.custom_fields || {});
                      return (
                        <div key={t.id} {...dragProps(t.id)} onContextMenu={(e) => { e.preventDefault(); openMenu(t.id, e.clientX, e.clientY); }} className="group relative cursor-grab rounded-lg border border-[#26262f] bg-[#0d0d12] p-3 transition hover:border-[#3a3a46] active:cursor-grabbing">
                          <div className="absolute right-2 top-2 flex items-center gap-0.5 opacity-0 transition group-hover:opacity-100">
                            <button title="Mark complete" onClick={(e) => { e.stopPropagation(); move(t.id, 'complete'); }} className="flex h-6 w-6 items-center justify-center rounded text-zinc-400 hover:bg-[#22222b] hover:text-emerald-400"><Icon n="check" size={14} /></button>
                            <button title="More" onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); openMenu(t.id, r.right - 220, r.bottom + 4); }} className="flex h-6 w-6 items-center justify-center rounded text-zinc-400 hover:bg-[#22222b] hover:text-zinc-100"><Icon n="dots" size={14} /></button>
                          </div>
                          <p className="pr-12 text-sm font-semibold text-zinc-100">{t.name}</p>
                          {t.description && <p className="mt-1 line-clamp-2 text-xs text-zinc-500">{t.description}</p>}
                          <div className="mt-2 flex flex-wrap gap-1.5"><TaskMeta t={t} /></div>
                          {cust.length > 0 && <div className="mt-2 space-y-0.5 border-t border-[#1e1e26] pt-2">{cust.slice(0, 4).map(([k, v]) => <div key={k} className="flex gap-2 text-[11px]"><span className="text-zinc-500">{k}:</span><span className="truncate text-zinc-300">{String(v)}</span></div>)}</div>}
                        </div>
                      );
                    })}
                    {adding === s ? addTaskInput(s)
                      : <button onClick={() => { setAdding(s); setAddText(''); }} className="flex w-full items-center gap-1.5 rounded-lg px-2 py-1.5 text-left text-xs font-semibold text-zinc-500 transition hover:bg-[#1c1c22] hover:text-zinc-200"><Icon n="plus" size={13} /> Add Task</button>}
                  </div>
                </div>
              );
            })}
            <div className="w-[220px] shrink-0 pt-1">
              {newGroup
                ? <input autoFocus value={newText} onChange={(e) => setNewText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') addGroup(); if (e.key === 'Escape') { setNewGroup(false); setNewText(''); } }} onBlur={addGroup} placeholder="Group name, then Enter" className="w-full rounded-lg border border-cu-purple bg-[#14141a] px-3 py-2 text-sm text-zinc-100 outline-none" />
                : <button onClick={() => { setNewGroup(true); setNewText(''); }} className="flex w-full items-center gap-1.5 rounded-lg border border-dashed border-[#26262f] px-3 py-2 text-sm font-semibold text-zinc-500 transition hover:border-cu-purple/60 hover:text-zinc-200"><Icon n="plus" size={15} /> Add group</button>}
            </div>
          </div>
        </div>
      )}

      {colMenu && colByKey(colMenu.key) && (
        <>
          <div className="fixed inset-0 z-[90]" onClick={() => setColMenu(null)} />
          <div className="fixed z-[95] w-[180px] rounded-xl border border-[#26262f] bg-[#0d0d12] p-1.5 shadow-2xl" style={{ left: colMenu.x, top: colMenu.y }}>
            <MenuItem icon="pen" label="Rename" onClick={() => { const c = colByKey(colMenu.key); setColMenu(null); renameGroup(c); }} />
            <MenuItem icon="chevUp" label="Collapse" onClick={() => { setCollapsed((m) => ({ ...m, [colMenu.key]: true })); setColMenu(null); }} />
            <div className="my-1 h-px bg-[#1e1e26]" />
            <MenuItem icon="trash" label="Delete group" danger onClick={() => { const c = colByKey(colMenu.key); setColMenu(null); deleteGroup(c); }} />
          </div>
        </>
      )}

      {menu && menuTask && (
        <>
          <div className="fixed inset-0 z-[90]" onClick={() => setMenu(null)} onContextMenu={(e) => { e.preventDefault(); setMenu(null); }} />
          <div className="fixed z-[95] w-[220px] rounded-xl border border-[#26262f] bg-[#0d0d12] p-1.5 shadow-2xl" style={{ left: menu.x, top: menu.y }}>
            <p className="truncate px-2.5 pb-1 pt-1 text-[11px] font-semibold text-zinc-500">{menuTask.name}</p>
            <MenuItem icon="pen" label="Rename" onClick={() => { setMenu(null); renameTask(menuTask); }} />
            <MenuItem icon="copy" label="Duplicate" onClick={() => { dup(menuTask.id); setMenu(null); }} />
            <MenuItem icon="check" label="Mark complete" onClick={() => { move(menuTask.id, 'complete'); setMenu(null); }} />
            <div className="my-1 h-px bg-[#1e1e26]" />
            <p className="px-2.5 pb-1 text-[10px] font-bold uppercase tracking-wide text-zinc-600">Move to</p>
            <div className="flex flex-wrap gap-1 px-2 pb-1.5">{cols.map((c) => <button key={c.key} onClick={() => { move(menuTask.id, c.key); setMenu(null); }} className={cn('rounded px-2 py-1 text-[10px] font-semibold', menuTask.status === c.key && 'ring-1 ring-white/30')} style={{ background: c.color + '22', color: c.color }}>{c.label}</button>)}</div>
            <p className="px-2.5 pb-1 text-[10px] font-bold uppercase tracking-wide text-zinc-600">Priority</p>
            <div className="flex items-center gap-1 px-2 pb-1.5">
              {Object.keys(PRIORITIES).map((pk) => <button key={pk} title={PRIORITIES[pk].label} onClick={() => { patch(menuTask.id, { priority: pk }); setMenu(null); }} className="flex-1 rounded py-1.5 hover:bg-[#1c1c22]"><span className="mx-auto block h-2.5 w-2.5 rounded-full" style={{ background: PRIORITIES[pk].color }} /></button>)}
              <button title="None" onClick={() => { patch(menuTask.id, { priority: '' }); setMenu(null); }} className="flex-1 rounded py-1 text-[10px] text-zinc-500 hover:bg-[#1c1c22]">None</button>
            </div>
            <div className="my-1 h-px bg-[#1e1e26]" />
            <MenuItem icon="trash" label="Delete" danger onClick={() => { del(menuTask.id); setMenu(null); }} />
          </div>
        </>
      )}
    </div>
  );
}
