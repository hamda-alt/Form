'use client';
import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Icon } from './icons';
import { cn } from './ui';
import { TEMPLATES } from '@/lib/templates';
import { createFormFromTemplate, deleteForm } from '@/lib/actions';

const NEW = '__new__';

export default function FormsHub({ forms = [], spaces = [] }) {
  const router = useRouter();
  const [view, setView] = useState('gallery'); // gallery | location
  const [pendingTpl, setPendingTpl] = useState(null);
  const [list, setList] = useState(forms);
  const removeForm = async (e, id) => {
    e.preventDefault(); e.stopPropagation();
    if (!window.confirm('Delete this form? Generated tasks are kept.')) return;
    setList((l) => l.filter((x) => x.id !== id));      // optimistic — won't reappear
    try { await deleteForm(id); } catch { router.refresh(); }
  };

  const locLabel = (form) => {
    if (form.list_id) { for (const s of spaces) { const l = s.lists.find((x) => x.id === form.list_id); if (l) return `${s.name} / ${l.name}`; } }
    const s = spaces.find((x) => x.id === form.space_id); return s ? s.name : 'Workspace';
  };

  if (view === 'location') {
    return <LocationPicker spaces={spaces} onClose={() => setView('gallery')}
      onCreate={async (loc) => { const { id } = await createFormFromTemplate({ templateKey: pendingTpl, ...loc }); router.push(`/forms/${id}`); }} />;
  }

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="mx-auto max-w-4xl px-6 py-14">
        {list.length > 0 && (
          <div className="mb-12">
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-zinc-500">Your forms</h2>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {list.map((f) => (
                <div key={f.id} className="group rounded-xl border border-[#22222a] bg-[#141418] p-4 transition hover:border-[#3a3a46]">
                  <div className="flex items-start justify-between gap-2">
                    <Link href={`/forms/${f.id}`} className="min-w-0 flex-1"><h3 className="truncate text-sm font-semibold text-zinc-100">{f.name}</h3><p className="mt-1 flex items-center gap-1 text-xs text-zinc-500"><Icon n="pin" size={12} />{locLabel(f)}</p></Link>
                    <div className="flex shrink-0 items-center gap-1">
                      <span className={cn('rounded-full px-2 py-0.5 text-[11px] font-semibold', f.status === 'published' ? 'bg-[#10B981]/15 text-[#34d399]' : 'bg-[#F5A524]/15 text-[#f5c17a]')}>{f.status === 'published' ? 'Published' : 'Draft'}</span>
                      <button onClick={(e) => removeForm(e, f.id)} title="Delete form" className="rounded-md p-1 text-zinc-500 opacity-0 transition hover:bg-[#22222b] hover:text-red-400 group-hover:opacity-100"><Icon n="trash" size={14} /></button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <h1 className="text-center text-[26px] font-extrabold tracking-tight text-white" style={{ textWrap: 'balance' }}>Choose a Form template</h1>
        <p className="mx-auto mt-2 max-w-md text-center text-sm text-zinc-500">Create forms to kick off projects, collect feedback, and supercharge your productivity.</p>
        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {TEMPLATES.map((t) => (
            <button key={t.key} onClick={() => { setPendingTpl(t.key); setView('location'); }}
              className="group flex flex-col rounded-xl border border-[#22222a] bg-[#141418] p-5 text-left transition hover:-translate-y-0.5 hover:border-[#3a3a46] hover:bg-[#17171c] hover:shadow-lg">
              <span className="flex h-12 w-12 items-center justify-center rounded-full" style={{ background: t.accent + '22', color: t.accent }}><Icon n={t.icon} size={22} /></span>
              <span className="mt-4 text-[15px] font-bold text-zinc-100">{t.name}</span>
              {t.desc && <span className="mt-1 text-[13px] leading-snug text-zinc-500">{t.desc}</span>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function LocationPicker({ spaces, onClose, onCreate }) {
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const ql = q.trim().toLowerCase();

  const filtered = useMemo(() => {
    if (!spaces.length) return [];
    return spaces
      .map((s) => ({ ...s, lists: s.lists.filter((l) => !ql || l.name.toLowerCase().includes(ql) || s.name.toLowerCase().includes(ql)) }))
      .filter((s) => s.lists.length);
  }, [spaces, ql]);

  const create = async (loc) => { setBusy(true); try { await onCreate(loc); } catch (e) { setBusy(false); alert(e.message || 'Could not create form'); } };

  const hasSpaces = spaces.length > 0;

  return (
    <div className="relative flex-1 overflow-y-auto">
      <button onClick={onClose} title="Close" className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full bg-[#1c1c22] text-zinc-400 hover:text-zinc-100"><Icon n="x" size={16} /></button>
      <div className="mx-auto max-w-xl px-6 py-16 text-center">
        <h1 className="text-[26px] font-extrabold text-white" style={{ textWrap: 'balance' }}>Where do you want submissions saved?</h1>
        <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-zinc-500">When a user submits a form, a task is created.<br />Select a List for responses.</p>
        <div className="mt-8 rounded-xl border border-[#26262f] bg-[#0f0f13] p-3 text-left shadow-xl">
          <div className="flex items-center gap-2 rounded-lg border border-[#26262f] bg-[#141418] px-3 py-2">
            <Icon n="search" size={15} className="text-zinc-500" />
            <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search..." className="w-full bg-transparent text-sm text-zinc-100 placeholder:text-zinc-600 outline-none" />
          </div>
          <div className="mt-3 max-h-[320px] overflow-y-auto">
            <p className="px-1 pb-1 text-[11px] font-bold uppercase tracking-wide text-zinc-600">Spaces</p>
            {!hasSpaces && (
              <button disabled={busy} onClick={() => create({ newSpaceName: 'My Workspace', newListName: 'Incoming', listId: NEW })}
                className="flex w-full items-center gap-2 rounded-md px-2 py-3 text-left text-sm text-zinc-200 hover:bg-[#1c1c22]">
                <Icon n="plus" size={15} className="text-cu-purpleTint" /> Create “My Workspace / Incoming” and continue
              </button>
            )}
            {filtered.map((s) => (
              <div key={s.id} className="mb-1">
                <div className="flex items-center gap-2 rounded-md px-1.5 py-1.5 text-sm font-semibold text-zinc-200"><span className="flex h-5 w-5 items-center justify-center rounded text-[10px] font-bold text-white" style={{ background: s.color || '#7B68EE' }}>{s.name[0]}</span>{s.name}</div>
                {s.lists.map((l) => (
                  <button key={l.id} disabled={busy} onClick={() => create({ spaceId: s.id, listId: l.id })}
                    className="flex w-full items-center gap-2 rounded-md py-1.5 pl-8 pr-2 text-left text-sm text-zinc-300 transition hover:bg-[#1c1c22] disabled:opacity-50"><Icon n="checks" size={15} className="text-zinc-500" />{l.name}</button>
                ))}
                <button key={s.id + '-new'} disabled={busy} onClick={() => create({ spaceId: s.id, listId: NEW, newListName: 'New list' })}
                  className="flex w-full items-center gap-2 rounded-md py-1.5 pl-8 pr-2 text-left text-xs text-zinc-500 hover:bg-[#1c1c22]"><Icon n="plus" size={13} /> New list in {s.name}</button>
              </div>
            ))}
            {hasSpaces && filtered.length === 0 && <p className="px-1 py-4 text-sm text-zinc-600">No matching lists</p>}
          </div>
        </div>
        {busy && <p className="mt-4 text-sm text-zinc-500">Creating form…</p>}
      </div>
    </div>
  );
}
