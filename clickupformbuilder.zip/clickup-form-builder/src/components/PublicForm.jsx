'use client';
import { useMemo, useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { Icon } from './icons';
import { cn } from './ui';
import SignaturePad from './SignaturePad';
import { keyOf } from '@/lib/fieldTypes';

// Stable wrapper at module scope so field subtrees never remount on re-render.
function FieldShell({ field, dark, error, children }) {
  return (
    <div>
      <label className={cn('mb-1.5 block text-sm font-medium', dark ? 'text-zinc-200' : 'text-zinc-700')}>
        {field.label}{field.required && <span className="text-red-500"> *</span>}
      </label>
      {children}
      {field.help_text && <p className={cn('mt-1 text-xs', dark ? 'text-zinc-500' : 'text-zinc-400')}>{field.help_text}</p>}
      {error && <p className="mt-1 text-xs font-medium text-red-500">{error.message}</p>}
    </div>
  );
}

function StarRow({ value = 0, scale = 5, color, onChange }) {
  return (
    <div className="flex gap-1.5">
      {Array.from({ length: scale }).map((_, i) => (
        <button type="button" key={i} onClick={() => onChange(i + 1)} aria-label={`${i + 1} star`}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill={i < value ? color : 'transparent'} stroke={color} strokeWidth="2" style={{ opacity: i < value ? 1 : 0.4 }}>
            <path d="M12 3.5l2.6 5.7 6.2.6-4.7 4.1 1.4 6L12 16.9 6.5 19.9l1.4-6-4.7-4.1 6.2-.6z" />
          </svg>
        </button>
      ))}
    </div>
  );
}

function FieldControl({ field, dark, primary, register, control, error }) {
  if (field.field_type === 'info_block') {
    return (
      <div className={cn('rounded-lg border px-4 py-3', dark ? 'border-white/10 bg-white/5' : 'border-black/10 bg-black/5')}>
        <p className={cn('text-sm font-semibold', dark ? 'text-zinc-100' : 'text-zinc-800')}>{field.label}</p>
        {field.help_text && <p className={cn('mt-1 text-sm', dark ? 'text-zinc-400' : 'text-zinc-500')}>{field.help_text}</p>}
      </div>
    );
  }
  const key = keyOf(field);
  const req = field.required ? { required: `${field.label} is required` } : {};
  const inp = dark ? 'border-white/15 bg-white/5 text-white placeholder:text-zinc-500' : 'border-black/15 bg-white text-zinc-900 placeholder:text-zinc-400';
  const base = `w-full rounded-lg border px-3 py-2.5 text-sm focus:outline-none focus:ring-2 transition ${inp}`;
  const ring = { boxShadow: undefined };

  const shell = (children) => <FieldShell field={field} dark={dark} error={error}>{children}</FieldShell>;

  switch (field.field_type) {
    case 'long_text':
      return shell(<textarea {...register(key, req)} placeholder={field.placeholder} rows={4} className={`${base} resize-y`} style={ring} />);
    case 'email':
      return shell(<input type="email" {...register(key, { ...req, pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email' } })} placeholder={field.placeholder || 'you@example.com'} className={base} />);
    case 'phone':
      return shell(<input type="tel" {...register(key, req)} placeholder={field.placeholder || '+1 555 000 0000'} className={base} />);
    case 'number':
      return shell(<input type="number" {...register(key, req)} placeholder={field.placeholder} className={base} />);
    case 'date':
      return shell(<input type="date" {...register(key, req)} className={base} style={{ colorScheme: dark ? 'dark' : 'light' }} />);
    case 'dropdown':
      return shell(
        <select {...register(key, req)} defaultValue="" className={`${base} cursor-pointer`}>
          <option value="" disabled>{field.placeholder || 'Select…'}</option>
          {(field.options || []).map((o, i) => <option key={i} value={o.value ?? o.label}>{o.label}</option>)}
        </select>,
      );
    case 'multi_select':
      return shell(
        <Controller name={key} control={control} defaultValue={[]} rules={req}
          render={({ field: { value = [], onChange } }) => (
            <div className="flex flex-wrap gap-2">
              {(field.options || []).map((o, i) => {
                const val = o.value ?? o.label; const on = value.includes(val);
                return (
                  <button type="button" key={i} onClick={() => onChange(on ? value.filter((v) => v !== val) : [...value, val])}
                    className={cn('rounded-full border px-3 py-1.5 text-xs font-medium transition', on ? 'text-white' : dark ? 'border-white/15 text-zinc-300' : 'border-black/15 text-zinc-600')}
                    style={on ? { background: primary, borderColor: primary } : undefined}>{o.label}</button>
                );
              })}
            </div>
          )} />,
      );
    case 'checkbox':
      return (
        <div>
          <Controller name={key} control={control} defaultValue={false} rules={req}
            render={({ field: { value, onChange } }) => (
              <label className="flex cursor-pointer items-start gap-2.5">
                <input type="checkbox" checked={!!value} onChange={(e) => onChange(e.target.checked)} className="mt-0.5 h-4 w-4" style={{ accentColor: primary }} />
                <span className={cn('text-sm', dark ? 'text-zinc-200' : 'text-zinc-700')}>{field.label}{field.required && <span className="text-red-500"> *</span>}</span>
              </label>
            )} />
          {field.help_text && <p className={cn('mt-1 text-xs', dark ? 'text-zinc-500' : 'text-zinc-400')}>{field.help_text}</p>}
          {error && <p className="mt-1 text-xs font-medium text-red-500">{error.message}</p>}
        </div>
      );
    case 'rating':
      return shell(<Controller name={key} control={control} defaultValue={0} rules={req} render={({ field: { value, onChange } }) => <StarRow value={value} scale={field.config?.scale || 5} color={primary} onChange={onChange} />} />);
    case 'file_upload':
      return shell(
        <Controller name={key} control={control} defaultValue="" rules={req}
          render={({ field: { value, onChange } }) => (
            <label className={cn('flex cursor-pointer items-center gap-3 rounded-lg border border-dashed px-4 py-3 text-sm', dark ? 'border-white/20 text-zinc-300' : 'border-black/20 text-zinc-600')}>
              <Icon n="upload" size={16} style={{ color: primary }} />
              <span className="truncate">{value || 'Choose a file…'}</span>
              <input type="file" className="hidden" accept={field.config?.accept || undefined} onChange={(e) => onChange(e.target.files?.[0]?.name || '')} />
            </label>
          )} />,
      );
    case 'signature':
      return shell(<Controller name={key} control={control} defaultValue="" rules={req} render={({ field: { value, onChange } }) => <SignaturePad value={value} onChange={onChange} />} />);
    default:
      return shell(<input type="text" {...register(key, req)} placeholder={field.placeholder} className={base} />);
  }
}

export default function PublicForm({ form, fields, preview = false }) {
  const dark = form.theme === 'dark';
  const primary = form.primary_color || '#7B68EE';
  const { register, handleSubmit, control, formState: { errors }, reset } = useForm({ mode: 'onBlur' });
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(null);
  const [serverError, setServerError] = useState('');
  const sorted = useMemo(() => [...(fields || [])].sort((a, b) => (a.position || 0) - (b.position || 0)), [fields]);

  const onSubmit = async (values) => {
    setServerError('');
    if (preview) { setDone({ successMessage: form.success_message || 'Thanks! Your response has been recorded.' }); return; }
    setSubmitting(true);
    try {
      const res = await fetch(`/api/forms/${form.public_id}/submit`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ answers: values }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Submission failed');
      setDone({ successMessage: data.successMessage || form.success_message, redirectUrl: data.redirectUrl });
      reset();
      if (data.redirectUrl) setTimeout(() => { window.location.href = data.redirectUrl; }, 1200);
    } catch (e) {
      setServerError(e.message || 'Something went wrong.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className={cn('min-h-full w-full', dark ? 'bg-[#0f0f14]' : 'bg-zinc-100')}>
      <div className="mx-auto w-full max-w-xl px-5 py-10">
        <div className={cn('overflow-hidden rounded-2xl border shadow-xl', dark ? 'border-white/10 bg-[#1b1b23]' : 'border-black/10 bg-white')}>
          <div className="h-1.5 w-full" style={{ background: primary }} />
          <div className="px-6 py-7 sm:px-8">
            <h1 className={cn('text-2xl font-extrabold tracking-tight', dark ? 'text-white' : 'text-zinc-900')}>{form.name}</h1>
            {form.description && <p className={cn('mt-2 text-sm', dark ? 'text-zinc-400' : 'text-zinc-500')}>{form.description}</p>}
            <div className="mt-6">
              {done ? (
                <div className="flex flex-col items-center py-8 text-center">
                  <Icon n="checkCircle" size={44} style={{ color: primary }} />
                  <p className={cn('mt-3 text-base font-bold', dark ? 'text-white' : 'text-zinc-900')}>{done.successMessage}</p>
                  {done.redirectUrl && <p className={cn('mt-1 text-xs', dark ? 'text-zinc-500' : 'text-zinc-400')}>Redirecting…</p>}
                  {preview && <button onClick={() => setDone(null)} className="mt-4 text-xs font-semibold underline" style={{ color: primary }}>Submit another</button>}
                </div>
              ) : sorted.length === 0 ? (
                <p className={cn('py-8 text-center text-sm', dark ? 'text-zinc-500' : 'text-zinc-400')}>This form has no fields yet.</p>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-5" noValidate>
                  {sorted.map((f) => <FieldControl key={f.id || f.field_key} field={f} dark={dark} primary={primary} register={register} control={control} error={errors[keyOf(f)]} />)}
                  {serverError && <div className="flex items-start gap-2 rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-500"><Icon n="info" size={16} /> {serverError}</div>}
                  <button type="submit" disabled={submitting} className="flex w-full items-center justify-center gap-2 rounded-lg px-4 py-3 text-sm font-bold text-white shadow transition hover:opacity-90 disabled:opacity-60" style={{ background: primary }}>
                    {submitting && <Icon n="loader" size={16} className="animate-spin" />}{form.submit_label || 'Submit'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
        {form.branding_enabled && <p className={cn('mt-4 text-center text-xs', dark ? 'text-zinc-600' : 'text-zinc-400')}>Powered by <span className="font-bold" style={{ color: primary }}>TAKSAM Forms</span></p>}
      </div>
    </div>
  );
}
