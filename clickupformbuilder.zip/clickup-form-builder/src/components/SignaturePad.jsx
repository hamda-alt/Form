'use client';
import { useRef, useEffect, useState } from 'react';

export default function SignaturePad({ value, onChange }) {
  const ref = useRef(null);
  const drawing = useRef(false);
  const last = useRef({ x: 0, y: 0 });
  const [ink, setInk] = useState(!!value);

  useEffect(() => {
    const c = ref.current;
    const dpr = window.devicePixelRatio || 1;
    const r = c.getBoundingClientRect();
    c.width = r.width * dpr; c.height = 140 * dpr;
    const ctx = c.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.strokeStyle = '#111827';
  }, []);

  const pos = (e) => { const r = ref.current.getBoundingClientRect(); const t = e.touches?.[0]; return { x: (t ? t.clientX : e.clientX) - r.left, y: (t ? t.clientY : e.clientY) - r.top }; };
  const down = (e) => { drawing.current = true; last.current = pos(e); };
  const move = (e) => { if (!drawing.current) return; e.preventDefault(); const ctx = ref.current.getContext('2d'); const p = pos(e); ctx.beginPath(); ctx.moveTo(last.current.x, last.current.y); ctx.lineTo(p.x, p.y); ctx.stroke(); last.current = p; if (!ink) setInk(true); };
  const up = () => { if (drawing.current) { drawing.current = false; onChange(ref.current.toDataURL()); } };
  const clear = () => { const c = ref.current; c.getContext('2d').clearRect(0, 0, c.width, c.height); setInk(false); onChange(''); };

  return (
    <div className="relative rounded-lg border border-black/15 bg-white" style={{ height: 140 }}>
      <canvas ref={ref} style={{ width: '100%', height: 140, touchAction: 'none', cursor: 'crosshair' }}
        onMouseDown={down} onMouseMove={move} onMouseUp={up} onMouseLeave={up} onTouchStart={down} onTouchMove={move} onTouchEnd={up} />
      {!ink && <span className="pointer-events-none absolute inset-0 flex items-center justify-center text-sm text-black/30">Sign here</span>}
      {ink && <button type="button" onClick={clear} className="absolute right-2 top-2 rounded bg-black/5 px-2 py-1 text-xs text-black/60 hover:bg-black/10">Clear</button>}
    </div>
  );
}
