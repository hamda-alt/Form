'use client';
import { useRouter } from 'next/navigation';
import { Icon } from './icons';
import { cn, IconBtn } from './ui';

export function Rail() {
  const router = useRouter();
  // Only the Forms icon (requested), shown as the glowing active section.
  const glow = 'bg-cu-purple text-white shadow-[0_0_14px_rgba(123,104,238,0.75)]';
  return (
    <div className="flex w-[52px] shrink-0 flex-col items-center gap-1.5 border-r border-[#1e1e24] bg-[#0f0f12] py-2">
      <button onClick={() => router.push('/forms')} title="Forms" className={cn('flex h-9 w-9 items-center justify-center rounded-lg transition-all', glow)}>
        <Icon n="checkbox" />
      </button>
    </div>
  );
}

export function TopBar() {
  const dim = 'text-zinc-500 hover:text-zinc-200';
  return (
    <div className="flex h-11 shrink-0 items-center gap-3 border-b border-[#1e1e24] bg-[#141417] px-3">
      <button className="flex items-center gap-2 rounded-md px-2 py-1 hover:bg-[#1e1e24]">
        <span className="flex h-5 w-5 items-center justify-center rounded bg-gradient-to-br from-cu-purple to-[#4a2d7a] text-[10px] font-bold text-white">T</span>
        <span className="text-sm font-semibold text-zinc-100">Talha Tahir&apos;s Workspace</span>
        <Icon n="chevDown" size={14} className="text-zinc-500" />
      </button>
      <button className={cn('rounded-md p-1', dim)}><Icon n="cal" size={16} /></button>
      <div className="mx-auto flex items-center gap-2">
        <button className={cn('rounded p-1', dim)}><Icon n="back" size={16} /></button>
        <button className={cn('rounded p-1', dim)}><Icon n="fwd" size={16} /></button>
        <div className="flex w-[360px] max-w-[40vw] items-center gap-2 rounded-lg border border-[#26262f] bg-[#0f0f13] px-3 py-1.5">
          <Icon n="search" size={15} className="text-zinc-500" />
          <span className="text-sm text-zinc-500">Search</span>
          <span className="ml-auto rounded bg-[#22222b] px-1.5 py-0.5 text-[10px] text-zinc-500">Ctrl J</span>
        </div>
        <button className="flex items-center gap-1.5 rounded-lg border border-[#26262f] px-2.5 py-1.5 text-xs font-semibold text-zinc-300 hover:bg-[#1e1e24]"><Icon n="spark" size={14} className="text-cu-purpleTint" /> AI Chats</button>
      </div>
      <div className="flex items-center gap-1">
        {['check', 'clip', 'video', 'mic', 'bell'].map((n) => <button key={n} className={cn('rounded p-1.5', dim)}><Icon n={n} size={16} /></button>)}
        <div className="ml-1 h-7 w-7 rounded-full bg-gradient-to-br from-cu-purple to-[#EC4899] ring-2 ring-[#2c1b4d]" />
      </div>
    </div>
  );
}

export function FormsSidebar() {
  return (
    <div className="hidden w-[228px] shrink-0 flex-col border-r border-[#1e1e24] bg-[#0f0f13] md:flex">
      <div className="flex items-center justify-between px-3 py-3">
        <h2 className="text-sm font-extrabold text-zinc-100">Forms</h2>
        <IconBtn className="h-7 w-7"><Icon n="plus" size={16} /></IconBtn>
      </div>
      <div className="px-2">
        <div className="flex items-center gap-2 rounded-lg bg-[#1c1c22] px-2.5 py-2 text-sm font-semibold text-zinc-100"><Icon n="checkbox" size={16} className="text-cu-purpleTint" /> All Forms</div>
        <div className="mt-0.5 flex items-center gap-2 rounded-lg px-2.5 py-2 text-sm text-zinc-400 hover:bg-[#16161a]"><span className="h-4 w-4 rounded-full bg-gradient-to-br from-[#F5A524] to-[#EC4899]" /> My Forms</div>
      </div>
      <div className="px-3 pt-5">
        <p className="text-[11px] font-bold uppercase tracking-wide text-zinc-600">Favorites</p>
        <div className="mt-2 flex flex-col items-center justify-center rounded-lg border border-dashed border-[#26262f] px-3 py-6 text-center">
          <Icon n="star" size={18} className="text-[#F5A524]" /><p className="mt-1.5 text-xs text-zinc-500">Star a Form to see it here</p>
        </div>
      </div>
    </div>
  );
}

// Page frame: TopBar + Rail + content.
export function Shell({ children }) {
  return (
    <div className="flex h-screen flex-col">
      <TopBar />
      <div className="flex min-h-0 flex-1">
        <Rail />
        {children}
      </div>
    </div>
  );
}

export function DbNotice({ error }) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
      <p className="text-base font-semibold text-zinc-200">Database not connected</p>
      <p className="max-w-md text-sm text-zinc-500">
        Set <code className="text-zinc-300">DATABASE_URL</code> in <code className="text-zinc-300">.env</code>, run{' '}
        <code className="text-zinc-300">npm run db:init</code>, then reload. See the README.
      </p>
      {error ? <pre className="mt-2 max-w-lg overflow-x-auto rounded bg-[#141418] p-3 text-left text-[11px] text-zinc-500">{String(error)}</pre> : null}
    </div>
  );
}
