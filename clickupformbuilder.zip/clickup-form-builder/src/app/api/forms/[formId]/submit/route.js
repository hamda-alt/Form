import { NextResponse } from 'next/server';
import { randomUUID } from 'node:crypto';
import { withTransaction, asJson } from '@/lib/db';
import { buildTaskFromAnswers } from '@/lib/mapping';

export const dynamic = 'force-dynamic';

// POST /api/forms/<public_id>/submit
// Body: { answers: { field_key: value }, meta? }
// Creates the form_submissions row AND the tasks row atomically (one txn).
export async function POST(req, { params }) {
  const publicId = params.formId;
  let body;
  try { body = await req.json(); } catch { return json({ error: 'Invalid JSON body' }, 400); }
  const answers = body && typeof body.answers === 'object' && body.answers ? body.answers : {};

  try {
    const result = await withTransaction(async (conn) => {
      // 1. Load + validate the form.
      const [forms] = await conn.query('SELECT * FROM forms WHERE public_id = ? LIMIT 1', [publicId]);
      const form = forms[0];
      if (!form) throw httpError('Form not found', 404);
      if (form.status !== 'published' || !(form.is_public === 1 || form.is_public === true)) {
        throw httpError('This form is not accepting submissions', 403);
      }
      form.task_template = asJson(form.task_template, {});

      const [fieldRows] = await conn.query('SELECT * FROM form_fields WHERE form_id = ? ORDER BY position', [form.id]);
      const fields = fieldRows.map((f) => ({ ...f, options: asJson(f.options, []), config: asJson(f.config, {}) }));

      // 2. Resolve the full location chain from whichever target the form uses.
      let space_id = form.space_id, folder_id = form.folder_id, list_id = form.list_id;
      if (list_id) {
        const [[l]] = await conn.query('SELECT space_id, folder_id FROM lists WHERE id = ?', [list_id]);
        if (l) { space_id = l.space_id; folder_id = l.folder_id; }
      } else if (folder_id) {
        const [[fo]] = await conn.query('SELECT space_id FROM folders WHERE id = ?', [folder_id]);
        if (fo) space_id = fo.space_id;
      }

      // 3. Insert the submission (task_id filled after the task exists).
      const submissionId = randomUUID();
      await conn.query(
        `INSERT INTO form_submissions (id, form_id, answers, respondent_name, respondent_email, meta)
         VALUES (?,?,?,?,?,?)`,
        [submissionId, form.id, JSON.stringify(answers),
         (answers.name || answers.full_name || null),
         (answers.email || answers.email_address || null),
         JSON.stringify({ ua: req.headers.get('user-agent') || '', submitted_at: new Date().toISOString(), ...(body.meta || {}) })],
      );

      // 4. Map answers -> task, then create it in the resolved location.
      const t = buildTaskFromAnswers(form, fields, answers);
      const taskId = randomUUID();
      await conn.query(
        `INSERT INTO tasks (id, space_id, folder_id, list_id, form_id, submission_id, name, description, status, priority, assignee_name, due_date, tags, custom_fields, position)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)`,
        [taskId, space_id, folder_id, list_id, form.id, submissionId, t.name, t.description, t.status, t.priority, t.assignee, t.due, JSON.stringify(t.tags), JSON.stringify(t.custom)],
      );

      // 5. Link submission -> task.
      await conn.query('UPDATE form_submissions SET task_id = ? WHERE id = ?', [taskId, submissionId]);

      return { submissionId, taskId, successMessage: form.success_message, redirectUrl: form.redirect_url };
    });

    return json({ ok: true, ...result });
  } catch (e) {
    return json({ error: e.message || 'Submission failed' }, e.status || 400);
  }
}

function json(body, status = 200) { return NextResponse.json(body, { status }); }
function httpError(message, status) { const e = new Error(message); e.status = status; return e; }
