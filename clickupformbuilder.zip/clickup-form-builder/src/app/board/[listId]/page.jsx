import { Shell, DbNotice } from '@/components/shell';
import Board from '@/components/Board';
import ViewTabs from '@/components/ViewTabs';
import { getListById, getTasks, getFormById } from '@/lib/data';

export const dynamic = 'force-dynamic';

export default async function BoardPage({ params, searchParams }) {
  const listId = params.listId === 'all' ? null : params.listId;
  const formId = searchParams?.form || null;
  let tasks = [], statuses = ['todo', 'in_progress', 'complete'], title = 'Board', error = null, form = null;
  try {
    if (formId) form = await getFormById(formId);
    if (listId) {
      const l = await getListById(listId);
      if (l) { statuses = Array.isArray(l.statuses) && l.statuses.length ? l.statuses : statuses; title = `${l.name} · Board`; }
      tasks = await getTasks({ listId, formId });
    } else if (formId) {
      if (form) title = `${form.name} · submissions`;
      tasks = await getTasks({ formId });
    } else {
      tasks = await getTasks({});
    }
  } catch (e) {
    error = e.message;
  }
  const tabListId = listId || form?.list_id || null;
  return (
    <Shell>
      {error ? <DbNotice error={error} /> : (
        <div className="flex min-w-0 flex-1 flex-col">
          <ViewTabs formId={formId} formName={form?.name} listId={tabListId} active="board" />
          <Board title={title} statuses={statuses} tasks={tasks} listId={listId} formId={formId} layout="board" />
        </div>
      )}
    </Shell>
  );
}
