import { notFound } from 'next/navigation';
import { Shell, DbNotice } from '@/components/shell';
import FormBuilder from '@/components/builder';
import ViewTabs from '@/components/ViewTabs';
import { getFormById, getFields, locationLabel } from '@/lib/data';

export const dynamic = 'force-dynamic';

export default async function BuilderPage({ params }) {
  let form, fields = [], label = '', error = null;
  try {
    form = await getFormById(params.id);
    if (!form) return notFound();
    fields = await getFields(params.id);
    label = await locationLabel(form);
  } catch (e) {
    error = e.message;
  }
  return (
    <Shell>
      {error ? <DbNotice error={error} /> : (
        <div className="flex min-w-0 flex-1 flex-col">
          <ViewTabs formId={form.id} formName={form.name} listId={form.list_id} active="form" />
          <FormBuilder initialForm={form} initialFields={fields} locationLabel={label} />
        </div>
      )}
    </Shell>
  );
}
