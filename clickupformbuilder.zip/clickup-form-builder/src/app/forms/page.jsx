import { Shell, FormsSidebar, DbNotice } from '@/components/shell';
import FormsHub from '@/components/FormsHub';
import { listForms, getSpacesTree } from '@/lib/data';

export const dynamic = 'force-dynamic';

export default async function FormsPage() {
  let forms = [], spaces = [], error = null;
  try {
    forms = await listForms();
    spaces = await getSpacesTree();
  } catch (e) {
    error = e.message;
  }
  return (
    <Shell>
      {error ? <DbNotice error={error} /> : (
        <>
          <FormsSidebar />
          <FormsHub forms={forms} spaces={spaces} />
        </>
      )}
    </Shell>
  );
}
