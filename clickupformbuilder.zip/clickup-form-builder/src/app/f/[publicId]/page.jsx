import PublicForm from '@/components/PublicForm';
import { getFormByPublicId, getFields } from '@/lib/data';

export const dynamic = 'force-dynamic';

function Closed({ dark = false, title, msg }) {
  return (
    <div className={`flex min-h-screen flex-col items-center justify-center gap-2 px-6 text-center ${dark ? 'bg-[#0f0f14] text-zinc-300' : 'bg-zinc-100 text-zinc-700'}`}>
      <p className="text-base font-semibold">{title}</p>
      {msg && <p className="max-w-md text-sm opacity-70">{msg}</p>}
    </div>
  );
}

export default async function PublicPage({ params }) {
  let form = null, fields = [], error = null;
  try {
    form = await getFormByPublicId(params.publicId);
    if (form) fields = await getFields(form.id);
  } catch (e) {
    error = e.message;
  }
  if (error) return <Closed title="Something went wrong" msg="Please try again later." />;
  if (!form) return <Closed title="Form not found" msg="This form doesn’t exist or was removed." />;
  if (form.status !== 'published' || !form.is_public) {
    return <Closed dark={form.theme === 'dark'} title="This form isn’t accepting responses right now." />;
  }
  return (
    <div className="min-h-screen">
      <PublicForm form={form} fields={fields} />
    </div>
  );
}
